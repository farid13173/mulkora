"use client";

import React from "react";
import { Property } from "@/types/property";
import { IconHeart, IconMapPin, IconPlay } from "./Icons";

interface PropertyCardProps {
  property: Property;
  isFavorite: boolean;
  onToggleFavorite: (id: number) => void;
  onOpenDetails: (property: Property) => void;
  onOpenReels: (property: Property) => void;
}

const formatPrice = (val: number) =>
  new Intl.NumberFormat("ru-RU").format(val);

export default function PropertyCard({
  property,
  isFavorite,
  onToggleFavorite,
  onOpenDetails,
  onOpenReels,
}: PropertyCardProps) {
  const pricePerMeter = Math.round(property.price / property.area);

  return (
    <article className="group relative flex flex-col overflow-hidden rounded-3xl border border-gray-100 bg-white shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl">
      {/* Image & Quick Triggers */}
      <div
        onClick={() => onOpenDetails(property)}
        className="relative h-60 w-full cursor-pointer overflow-hidden bg-gray-100"
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={property.images[0] || property.videoPoster}
          alt={property.title}
          className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />

        {/* Tag Badge */}
        <span className="absolute left-3 top-3 rounded-xl bg-white/95 px-3 py-1.5 text-xs font-bold text-[#102d42] shadow-sm backdrop-blur">
          {property.tag}
        </span>

        {/* Separate Reels Video Button on Card */}
        {property.videoUrl && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenReels(property);
            }}
            aria-label="Смотреть Reels видео-тур"
            className="absolute bottom-3 left-3 flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1.5 text-xs font-bold text-white backdrop-blur-md border border-white/20 transition hover:bg-[#19a99a] hover:scale-105 shadow-md active:scale-95"
          >
            <span className="flex h-2 w-2 rounded-full bg-[#19a99a] animate-pulse" />
            <IconPlay className="w-3.5 h-3.5 fill-white" />
            <span>Reels видео</span>
          </button>
        )}

        {/* Like Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(property.id);
          }}
          aria-label="В избранное"
          className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-gray-700 shadow-md backdrop-blur transition hover:scale-110 active:scale-95"
        >
          <IconHeart
            filled={isFavorite}
            className={`w-5 h-5 ${isFavorite ? "text-red-500 fill-red-500" : "text-gray-700"}`}
          />
        </button>
      </div>

      {/* Card Content */}
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-baseline justify-between">
          <div className="text-2xl font-black tracking-tight text-[#102d42]">
            {formatPrice(property.price)} {property.currency}
          </div>
          <span className="text-xs font-medium text-gray-400">
            ~{formatPrice(pricePerMeter)} ₼/м²
          </span>
        </div>

        <h3
          onClick={() => onOpenDetails(property)}
          className="mt-2 line-clamp-2 min-h-11 cursor-pointer text-sm font-bold text-gray-800 transition hover:text-[#19a99a]"
        >
          {property.title}
        </h3>

        <div className="mt-2 flex items-center gap-1 text-xs text-gray-500">
          <IconMapPin className="w-3.5 h-3.5 text-[#19a99a] shrink-0" />
          <span className="truncate">{property.location.district}</span>
          {property.location.metro && (
            <span className="text-gray-400 truncate">• {property.location.metro}</span>
          )}
        </div>

        {/* Feature Badges */}
        <div className="mt-3 flex flex-wrap gap-1.5 text-[11px]">
          {property.hasKupcha && (
            <span className="rounded-lg bg-emerald-50 px-2 py-0.5 font-semibold text-emerald-700">
              Купчая
            </span>
          )}
          {property.hasGas && (
            <span className="rounded-lg bg-amber-50 px-2 py-0.5 font-semibold text-amber-700">
              Газ
            </span>
          )}
          {property.isMortgage && (
            <span className="rounded-lg bg-blue-50 px-2 py-0.5 font-semibold text-blue-700">
              Ипотека
            </span>
          )}
        </div>

        {/* Specs Row */}
        <div className="mt-4 flex items-center justify-between border-t border-gray-100 pt-3 text-xs font-medium text-gray-600">
          <span>{property.rooms} комн.</span>
          <span>•</span>
          <span>{property.area} м²</span>
          <span>•</span>
          <span>{property.floor}</span>
        </div>

        {/* Dual Actions: Details & Reels */}
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            onClick={() => onOpenDetails(property)}
            className="flex items-center justify-center gap-1 rounded-xl bg-gray-50 py-2.5 text-xs font-bold text-[#102d42] transition hover:bg-[#102d42] hover:text-white"
          >
            <span>Подробнее</span>
            <span>→</span>
          </button>

          {property.videoUrl && (
            <button
              onClick={() => onOpenReels(property)}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-[#19a99a] to-[#148377] py-2.5 text-xs font-bold text-white shadow-sm transition hover:opacity-95"
            >
              <IconPlay className="w-3 h-3 fill-white" />
              <span>Смотреть Reels</span>
            </button>
          )}
        </div>
      </div>
    </article>
  );
}
