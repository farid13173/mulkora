"use client";

import React, { useState } from "react";
import { Property, PropertyType, DealType } from "@/types/property";
import { IconX } from "./Icons";

interface AddPropertyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (newProp: Property) => void;
}

export default function AddPropertyModal({
  isOpen,
  onClose,
  onAdd,
}: AddPropertyModalProps) {
  const [dealType, setDealType] = useState<DealType>("Продажа");
  const [type, setType] = useState<PropertyType>("Квартира");
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [district, setDistrict] = useState("Ясамальский район");
  const [metro, setMetro] = useState("");
  const [rooms, setRooms] = useState("3");
  const [area, setArea] = useState("");
  const [floor, setFloor] = useState("5/12");
  const [hasKupcha, setHasKupcha] = useState(true);
  const [hasGas, setHasGas] = useState(true);
  const [isMortgage, setIsMortgage] = useState(true);
  const [description, setDescription] = useState("");
  const [agentName, setAgentName] = useState("");
  const [phone, setPhone] = useState("+994 50 ");

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const cleanWhatsapp = phone.replace(/\D/g, "");

    const newProperty: Property = {
      id: Date.now(),
      type,
      dealType,
      title: title || `${type} в Баку (${district})`,
      location: {
        city: "Баку",
        district,
        metro: metro ? `м. ${metro}` : undefined,
        address: "Баку",
      },
      price: Number(price) || 200000,
      currency: "₼",
      rooms: Number(rooms) || 2,
      area: Number(area) || 90,
      floor: floor || "4/9",
      buildingType: "Новостройка",
      renovation: "Евроремонт",
      hasGas,
      hasKupcha,
      isMortgage,
      description:
        description ||
        "Отличное предложение на Mulkora. Все документы в порядке. Звоните для просмотра!",
      features: [
        hasKupcha ? "Купчая (Çıxarış)" : "Договор",
        hasGas ? "Газ подключен" : "Без газа",
        "Новый ремонт",
        "Паркинг",
      ],
      images: [
        "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200",
      ],
      videoUrl:
        "https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-interior-living-room-41315-large.mp4",
      videoPoster:
        "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=900",
      tag: "Новое",
      agent: {
        name: agentName || "Собственник",
        agency: "Mulkora Direct",
        phone: phone || "+994 50 123 45 67",
        whatsapp: cleanWhatsapp || "994501234567",
        avatar:
          "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200",
        rating: 5.0,
        verified: true,
      },
      viewsCount: 1,
      likesCount: 0,
      createdAt: "Только что",
    };

    onAdd(newProperty);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-fade-in">
      <div className="relative max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200"
        >
          <IconX className="w-5 h-5" />
        </button>

        <h3 className="text-2xl font-bold text-[#102d42]">
          Подать объявление на MULKORA
        </h3>
        <p className="mt-1 text-xs text-gray-500">
          Ваше объявление с видео-туром будет доступно в формате Reels для тысяч покупателей
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4 text-sm">
          {/* Deal type */}
          <div className="flex gap-2">
            {(["Продажа", "Аренда"] as DealType[]).map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setDealType(d)}
                className={`flex-1 rounded-xl py-2.5 font-bold transition ${
                  dealType === d
                    ? "bg-[#102d42] text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                {d}
              </button>
            ))}
          </div>

          {/* Property type */}
          <div>
            <label className="text-xs font-bold text-gray-700">Тип недвижимости</label>
            <div className="mt-1 grid grid-cols-3 gap-2">
              {(["Квартира", "Вилла", "Коммерция"] as PropertyType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`rounded-lg border py-2 text-xs font-semibold ${
                    type === t
                      ? "border-[#19a99a] bg-[#19a99a]/10 text-[#102d42]"
                      : "border-gray-200 text-gray-600"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="text-xs font-bold text-gray-700">Заголовок объявления</label>
            <input
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Например: 3-комнатная квартира с ремонтом в центре"
              className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
            />
          </div>

          {/* Price & Area */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-gray-700">Цена (AZN ₼)</label>
              <input
                required
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="245000"
                className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-700">Площадь (м²)</label>
              <input
                required
                type="number"
                value={area}
                onChange={(e) => setArea(e.target.value)}
                placeholder="120"
                className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
              />
            </div>
          </div>

          {/* District & Metro */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-gray-700">Район Баку</label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
              >
                <option>Ясамальский район</option>
                <option>Насиминский район</option>
                <option>Сабаильский район</option>
                <option>Хатаинский район</option>
                <option>Наримановский район</option>
                <option>Хазарский район (Шувелан, Мардакян)</option>
                <option>Бинагадинский район</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-gray-700">Метро (если есть)</label>
              <input
                value={metro}
                onChange={(e) => setMetro(e.target.value)}
                placeholder="Низами, Эльмляр, 28 Мая..."
                className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
              />
            </div>
          </div>

          {/* Rooms & Floor */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-gray-700">Комнат</label>
              <input
                type="number"
                value={rooms}
                onChange={(e) => setRooms(e.target.value)}
                placeholder="3"
                className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-700">Этаж</label>
              <input
                value={floor}
                onChange={(e) => setFloor(e.target.value)}
                placeholder="8/16"
                className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
              />
            </div>
          </div>

          {/* Checkboxes */}
          <div className="flex gap-4 text-xs font-semibold">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={hasKupcha}
                onChange={(e) => setHasKupcha(e.target.checked)}
                className="accent-[#19a99a]"
              />
              <span>Купчая (Çıxarış)</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={hasGas}
                onChange={(e) => setHasGas(e.target.checked)}
                className="accent-[#19a99a]"
              />
              <span>Газ</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={isMortgage}
                onChange={(e) => setIsMortgage(e.target.checked)}
                className="accent-[#19a99a]"
              />
              <span>Ипотека</span>
            </label>
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-bold text-gray-700">Описание</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Расскажите подробнее о ремонте, виде из окон, инфраструктуре..."
              className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
            />
          </div>

          {/* Contact Name & Phone */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-gray-700">Ваше имя</label>
              <input
                required
                value={agentName}
                onChange={(e) => setAgentName(e.target.value)}
                placeholder="Имя или Агентство"
                className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-700">Телефон (WhatsApp)</label>
              <input
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+994 50 123 45 67"
                className="mt-1 w-full rounded-xl border border-gray-200 p-3 text-sm outline-none focus:border-[#19a99a]"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full rounded-2xl bg-[#19a99a] py-3.5 text-base font-bold text-white shadow-lg transition hover:bg-[#138b80]"
          >
            Опубликовать объявление
          </button>
        </form>
      </div>
    </div>
  );
}
