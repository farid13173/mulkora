"use client";

import React, { useState } from "react";
import { Property } from "@/types/property";
import {
  IconX,
  IconHeart,
  IconShare,
  IconMapPin,
  IconWhatsApp,
  IconPhone,
  IconPlay,
  IconCheck,
} from "./Icons";

interface PropertyDetailModalProps {
  property: Property;
  isOpen: boolean;
  onClose: () => void;
  onOpenReels: (property: Property) => void;
  isFavorite: boolean;
  onToggleFavorite: (id: number) => void;
}

const formatPrice = (value: number) =>
  new Intl.NumberFormat("ru-RU").format(value);

export default function PropertyDetailModal({
  property,
  isOpen,
  onClose,
  onOpenReels,
  isFavorite,
  onToggleFavorite,
}: PropertyDetailModalProps) {
  const [activePhotoIndex, setActivePhotoIndex] = useState(0);
  const [copiedToast, setCopiedToast] = useState(false);

  if (!isOpen) return null;

  const pricePerMeter = Math.round(property.price / property.area);

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: property.title,
          text: `${property.title} — ${formatPrice(property.price)} ${property.currency}`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      setCopiedToast(true);
      setTimeout(() => setCopiedToast(false), 2000);
    }
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      `Здравствуйте, ${property.agent.name}! Меня заинтересовало объявление на Mulkora: "${property.title}" за ${formatPrice(property.price)} ${property.currency}. Хочу узнать подробнее.`
    );
    window.open(`https://wa.me/${property.agent.whatsapp}?text=${text}`, "_blank");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-2 sm:p-4 backdrop-blur-md overflow-y-auto">
      {/* Toast */}
      {copiedToast && (
        <div className="fixed top-6 z-[70] rounded-full bg-[#19a99a] px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-2xl animate-fade-in">
          Ссылка скопирована!
        </div>
      )}

      <div className="relative my-auto w-full max-w-4xl overflow-hidden rounded-3xl bg-white shadow-2xl animate-scale-up border border-gray-100 max-h-[94vh] flex flex-col">
        {/* Top Header Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between border-b border-gray-100 bg-white/95 px-6 py-4 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <span className="rounded-lg bg-[#102d42] px-3 py-1 text-xs font-bold text-white">
              {property.type} · {property.dealType}
            </span>
            <span className="rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700">
              {property.tag}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Share */}
            <button
              onClick={handleShare}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200 transition"
              aria-label="Поделиться"
            >
              <IconShare className="w-4 h-4" />
            </button>

            {/* Favorite */}
            <button
              onClick={() => onToggleFavorite(property.id)}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200 transition"
              aria-label="В избранное"
            >
              <IconHeart
                filled={isFavorite}
                className={`w-5 h-5 ${isFavorite ? "text-red-500 fill-red-500" : "text-gray-700"}`}
              />
            </button>

            {/* Close */}
            <button
              onClick={onClose}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 transition"
              aria-label="Закрыть"
            >
              <IconX className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="overflow-y-auto px-5 py-6 sm:px-8 space-y-6">
          {/* Photos & Reels Launch Box */}
          <div className="space-y-3">
            <div className="relative h-72 sm:h-96 w-full overflow-hidden rounded-2xl bg-gray-900 shadow-md">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={property.images[activePhotoIndex] || property.images[0]}
                alt={property.title}
                className="h-full w-full object-cover"
              />

              {/* Counter Badge */}
              <div className="absolute bottom-4 left-4 rounded-xl bg-black/60 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur-md">
                Фото {activePhotoIndex + 1} из {property.images.length}
              </div>

              {/* Separate Reels Video Launcher Button */}
              {property.videoUrl && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenReels(property);
                  }}
                  className="group absolute bottom-4 right-4 flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#19a99a] to-[#102d42] px-4 py-2.5 text-xs sm:text-sm font-extrabold text-white shadow-xl transition transform hover:scale-105 active:scale-95"
                >
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/20 text-white group-hover:bg-white group-hover:text-[#102d42] transition">
                    <IconPlay className="w-3.5 h-3.5 ml-0.5" />
                  </span>
                  <span>Смотреть видео-тур (Reels)</span>
                </button>
              )}
            </div>

            {/* Thumbnails Row */}
            {property.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {property.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActivePhotoIndex(idx)}
                    className={`relative h-16 w-24 flex-shrink-0 overflow-hidden rounded-xl border-2 transition ${
                      activePhotoIndex === idx
                        ? "border-[#19a99a] scale-105 shadow-md"
                        : "border-transparent opacity-70 hover:opacity-100"
                    }`}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={img}
                      alt="Thumbnail"
                      className="h-full w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Title & Price Section */}
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 border-b border-gray-100 pb-6">
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-[#102d42] leading-snug">
                {property.title}
              </h1>
              <div className="mt-2 flex items-center gap-2 text-sm text-gray-600">
                <IconMapPin className="w-4 h-4 text-[#19a99a] shrink-0" />
                <span>
                  {property.location.city}, {property.location.district},{" "}
                  {property.location.address}
                </span>
                {property.location.metro && (
                  <span className="rounded-md bg-emerald-50 px-2 py-0.5 text-xs font-semibold text-emerald-700">
                    {property.location.metro}
                  </span>
                )}
              </div>
            </div>

            <div className="sm:text-right shrink-0">
              <div className="text-3xl sm:text-4xl font-black text-[#102d42]">
                {formatPrice(property.price)} {property.currency}
              </div>
              <div className="mt-1 text-xs text-gray-500 font-semibold">
                ≈ {formatPrice(pricePerMeter)} ₼ за м²
              </div>
            </div>
          </div>

          {/* Key Specifications Grid */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
              Основные параметры
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
              <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100">
                <div className="text-xs text-gray-500">Количество комнат</div>
                <div className="mt-1 text-lg font-black text-[#102d42]">
                  {property.rooms} комн.
                </div>
              </div>

              <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100">
                <div className="text-xs text-gray-500">Общая площадь</div>
                <div className="mt-1 text-lg font-black text-[#102d42]">
                  {property.area} м²
                </div>
                {property.livingArea && (
                  <div className="text-[11px] text-gray-400">
                    жилая: {property.livingArea} м²
                  </div>
                )}
              </div>

              <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100">
                <div className="text-xs text-gray-500">Этаж / Этажность</div>
                <div className="mt-1 text-lg font-black text-[#102d42]">
                  {property.floor}
                </div>
              </div>

              <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100">
                <div className="text-xs text-gray-500">Тип строения</div>
                <div className="mt-1 text-lg font-black text-[#102d42]">
                  {property.buildingType}
                </div>
              </div>

              <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100">
                <div className="text-xs text-gray-500">Ремонт</div>
                <div className="mt-1 text-base font-bold text-[#102d42]">
                  {property.renovation}
                </div>
              </div>

              <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100">
                <div className="text-xs text-gray-500">Высота потолков</div>
                <div className="mt-1 text-base font-bold text-[#102d42]">
                  {property.ceilingHeight || "3.1 м"}
                </div>
              </div>

              <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100">
                <div className="text-xs text-gray-500">Отопление</div>
                <div className="mt-1 text-base font-bold text-[#102d42]">
                  {property.heating || "Комби"}
                </div>
              </div>

              <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100">
                <div className="text-xs text-gray-500">Кухня</div>
                <div className="mt-1 text-base font-bold text-[#102d42]">
                  {property.kitchenArea ? `${property.kitchenArea} м²` : "Просторная"}
                </div>
              </div>
            </div>
          </div>

          {/* Legal Status & Badges */}
          <div className="rounded-2xl border border-emerald-100 bg-emerald-50/50 p-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-900 mb-2">
              Юридический статус и коммуникации
            </h3>
            <div className="flex flex-wrap gap-2 text-xs">
              {property.hasKupcha && (
                <span className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-1.5 font-bold text-white shadow-sm">
                  <IconCheck className="w-3.5 h-3.5" />
                  Купчая есть (Çıxarış)
                </span>
              )}
              {property.hasGas && (
                <span className="flex items-center gap-1.5 rounded-xl bg-amber-500 px-3 py-1.5 font-bold text-white shadow-sm">
                  <IconCheck className="w-3.5 h-3.5" />
                  Газ подключен
                </span>
              )}
              {property.isMortgage && (
                <span className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3 py-1.5 font-bold text-white shadow-sm">
                  <IconCheck className="w-3.5 h-3.5" />
                  Подходит под ипотеку
                </span>
              )}
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">
              Подробное описание
            </h3>
            <p className="text-sm leading-relaxed text-gray-700 whitespace-pre-line bg-gray-50 p-4 rounded-2xl border border-gray-100">
              {property.description}
            </p>
          </div>

          {/* Features and Amenities */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">
              Особенности и удобства
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs text-gray-700">
              {property.features.map((feature, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 rounded-xl bg-gray-50 px-3 py-2 border border-gray-100"
                >
                  <div className="h-2 w-2 rounded-full bg-[#19a99a]" />
                  <span className="font-medium">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Agent Card & Call to Action */}
          <div className="rounded-3xl border border-gray-100 bg-[#f7f8fa] p-5 sm:p-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-4">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={property.agent.avatar}
                  alt={property.agent.name}
                  className="h-16 w-16 rounded-full object-cover border-2 border-white shadow-md"
                />
                <div>
                  <div className="flex items-center gap-1.5 text-base font-bold text-[#102d42]">
                    <span>{property.agent.name}</span>
                    <span className="flex h-4 w-4 items-center justify-center rounded-full bg-[#19a99a] text-[10px] text-white">
                      ✓
                    </span>
                  </div>
                  <div className="text-xs text-gray-500">
                    {property.agent.agency}
                  </div>
                  <div className="mt-1 text-xs font-semibold text-[#19a99a]">
                    ★ {property.agent.rating} рейтинг · проверенный специалист
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2.5">
                <button
                  onClick={handleWhatsApp}
                  className="flex items-center justify-center gap-2 rounded-2xl bg-[#25D366] px-5 py-3 text-xs sm:text-sm font-bold text-white shadow transition hover:opacity-95"
                >
                  <IconWhatsApp className="w-5 h-5" />
                  Написать в WhatsApp
                </button>
                <a
                  href={`tel:${property.agent.phone}`}
                  className="flex items-center justify-center gap-2 rounded-2xl bg-[#102d42] px-5 py-3 text-xs sm:text-sm font-bold text-white shadow transition hover:bg-[#19a99a]"
                >
                  <IconPhone className="w-5 h-5" />
                  Позвонить
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
