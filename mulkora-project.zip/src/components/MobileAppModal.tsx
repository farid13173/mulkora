"use client";

import React from "react";
import { IconX, IconSmartphone, IconCheck } from "./Icons";

interface MobileAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileAppModal({
  isOpen,
  onClose,
}: MobileAppModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg overflow-hidden rounded-3xl bg-white p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200"
          aria-label="Закрыть"
        >
          <IconX className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#102d42] text-white">
            <IconSmartphone className="w-6 h-6 text-[#52c9b8]" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-[#102d42]">
              MULKORA для iOS и Android
            </h3>
            <p className="text-xs text-gray-500">
              Полноценное приложение на вашем смартфоне
            </p>
          </div>
        </div>

        <div className="mt-6 space-y-4 text-sm text-gray-700">
          {/* Option 1: PWA */}
          <div className="rounded-2xl border border-emerald-100 bg-emerald-50/60 p-4">
            <div className="flex items-center gap-2 font-bold text-emerald-900">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-xs text-white">
                1
              </span>
              <span>Быстрый способ: Установка в 1 клик (PWA)</span>
            </div>
            <p className="mt-1 text-xs text-emerald-800 leading-relaxed">
              Сайт уже настроен как веб-приложение! Откройте его на телефоне:
            </p>
            <ul className="mt-2 space-y-1 text-xs text-emerald-900">
              <li className="flex items-center gap-1.5">
                <IconCheck className="w-3.5 h-3.5 text-emerald-600" />
                <strong>iPhone (Safari):</strong> Нажмите кнопку «Поделиться» → «На экран «Домой»».
              </li>
              <li className="flex items-center gap-1.5">
                <IconCheck className="w-3.5 h-3.5 text-emerald-600" />
                <strong>Android (Chrome):</strong> Нажмите меню (три точки) → «Установить приложение».
              </li>
            </ul>
          </div>

          {/* Option 2: React Native / Expo */}
          <div className="rounded-2xl border border-gray-100 bg-gray-50 p-4">
            <div className="flex items-center gap-2 font-bold text-[#102d42]">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#102d42] text-xs text-white">
                2
              </span>
              <span>Нативное приложение для App Store и Google Play (Expo)</span>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-gray-600">
              Мы можем создать нативный проект на <strong>React Native + Expo</strong>. Вы сможете открыть его прямо на телефоне через приложение <strong>Expo Go</strong>, протестировать жесты вертикального видео Reels, а затем скомпилировать готовые <strong>.apk (Android)</strong> и <strong>.ipa (iOS)</strong> для публикации в магазинах.
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-[#102d42] px-6 py-2.5 text-sm font-bold text-white transition hover:bg-[#19a99a]"
          >
            Понятно
          </button>
        </div>
      </div>
    </div>
  );
}
