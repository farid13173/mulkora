"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import { Property } from "@/types/property";
import {
  IconHeart,
  IconWhatsApp,
  IconPhone,
  IconShare,
  IconVolume2,
  IconVolumeX,
  IconPlay,
  IconPause,
  IconX,
  IconMapPin,
  IconChevronUp,
  IconChevronDown,
} from "./Icons";

interface PropertyReelsModalProps {
  property: Property;
  allProperties: Property[];
  isOpen: boolean;
  onClose: () => void;
  onSelectProperty: (property: Property) => void;
  onOpenDetails: (property: Property) => void;
  favorites: number[];
  onToggleFavorite: (id: number) => void;
}

const formatPrice = (value: number) =>
  new Intl.NumberFormat("ru-RU").format(value);

export default function PropertyReelsModal({
  property,
  allProperties,
  isOpen,
  onClose,
  onSelectProperty,
  onOpenDetails,
  favorites,
  onToggleFavorite,
}: PropertyReelsModalProps) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [showPlayIcon, setShowPlayIcon] = useState(false);
  const [copiedToast, setCopiedToast] = useState(false);
  const [progress, setProgress] = useState(0);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const touchStartY = useRef<number | null>(null);

  const currentIndex = allProperties.findIndex((p) => p.id === property.id);
  const isFav = favorites.includes(property.id);

  const goToNext = useCallback(() => {
    if (currentIndex < allProperties.length - 1) {
      onSelectProperty(allProperties[currentIndex + 1]);
    } else {
      onSelectProperty(allProperties[0]);
    }
  }, [allProperties, currentIndex, onSelectProperty]);

  const goToPrev = useCallback(() => {
    if (currentIndex > 0) {
      onSelectProperty(allProperties[currentIndex - 1]);
    } else {
      onSelectProperty(allProperties[allProperties.length - 1]);
    }
  }, [allProperties, currentIndex, onSelectProperty]);

  const togglePlayPause = useCallback(() => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
    setShowPlayIcon(true);
    setTimeout(() => setShowPlayIcon(false), 700);
  }, []);

  // Autoplay on property change
  useEffect(() => {
    if (isOpen && videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => setIsPlaying(false));
    }
  }, [property.id, isOpen]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      } else if (e.key === "ArrowDown") {
        goToNext();
      } else if (e.key === "ArrowUp") {
        goToPrev();
      } else if (e.key === "m" || e.key === "M") {
        setIsMuted((prev) => !prev);
      } else if (e.key === " ") {
        e.preventDefault();
        togglePlayPause();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, goToNext, goToPrev, onClose, togglePlayPause]);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartY.current === null) return;
    const touchEndY = e.changedTouches[0].clientY;
    const diff = touchStartY.current - touchEndY;

    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        goToNext();
      } else {
        goToPrev();
      }
    }
    touchStartY.current = null;
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: property.title,
          text: `${property.title} — ${formatPrice(property.price)} ${property.currency}`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      setCopiedToast(true);
      setTimeout(() => setCopiedToast(false), 2000);
    }
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      `Здравствуйте, ${property.agent.name}! Смотрю видео-тур на Mulkora: "${property.title}" (${formatPrice(property.price)} ${property.currency}). Можно подробности?`
    );
    window.open(`https://wa.me/${property.agent.whatsapp}?text=${text}`, "_blank");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md">
      {copiedToast && (
        <div className="absolute top-6 z-[80] rounded-full bg-[#19a99a] px-5 py-2.5 text-sm font-semibold text-white shadow-xl animate-fade-in">
          Ссылка скопирована в буфер обмена!
        </div>
      )}

      {/* Desktop Prev Button */}
      <button
        onClick={goToPrev}
        aria-label="Предыдущее видео"
        className="hidden lg:flex fixed left-8 top-1/2 -translate-y-1/2 h-14 w-14 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-md border border-white/20 transition hover:bg-white/20 hover:scale-110 shadow-2xl"
      >
        <IconChevronUp className="w-8 h-8" />
      </button>

      {/* Desktop Next Button */}
      <button
        onClick={goToNext}
        aria-label="Следующее видео"
        className="hidden lg:flex fixed right-8 top-1/2 -translate-y-1/2 h-14 w-14 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-md border border-white/20 transition hover:bg-white/20 hover:scale-110 shadow-2xl"
      >
        <IconChevronDown className="w-8 h-8" />
      </button>

      {/* Main Reels Container */}
      <div
        className="relative h-full w-full max-w-[440px] max-h-[100dvh] sm:max-h-[92vh] sm:rounded-[36px] overflow-hidden bg-black shadow-2xl border-0 sm:border sm:border-white/15 flex flex-col justify-between"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* Video Player */}
        <div
          onClick={togglePlayPause}
          className="absolute inset-0 cursor-pointer overflow-hidden bg-black"
        >
          <video
            ref={videoRef}
            src={property.videoUrl}
            poster={property.videoPoster}
            loop
            playsInline
            autoPlay
            muted={isMuted}
            onTimeUpdate={() => {
              if (videoRef.current) {
                const current = videoRef.current.currentTime;
                const total = videoRef.current.duration || 1;
                setProgress((current / total) * 100);
              }
            }}
            className="h-full w-full object-cover object-center"
          />

          {/* Vignette overlays */}
          <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black/80 via-black/30 to-transparent pointer-events-none" />
          <div className="absolute inset-x-0 bottom-0 h-72 bg-gradient-to-t from-black/95 via-black/60 to-transparent pointer-events-none" />

          {/* Central Play/Pause feedback */}
          {showPlayIcon && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur-sm">
                {isPlaying ? (
                  <IconPlay className="w-10 h-10 ml-1 text-white" />
                ) : (
                  <IconPause className="w-10 h-10 text-white" />
                )}
              </div>
            </div>
          )}
        </div>

        {/* Top Bar */}
        <div className="relative z-20 flex items-center justify-between px-4 pt-4 sm:pt-5">
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-black/40 backdrop-blur-md px-3 py-1 text-xs font-semibold text-white border border-white/20">
              Reels {currentIndex + 1} / {allProperties.length}
            </span>
            <span className="rounded-full bg-[#19a99a] px-3 py-1 text-xs font-bold text-white shadow-sm">
              {property.tag}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Sound toggle */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsMuted(!isMuted);
              }}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur-md border border-white/20 hover:bg-black/70 transition"
              aria-label={isMuted ? "Включить звук" : "Выключить звук"}
            >
              {isMuted ? (
                <IconVolumeX className="w-5 h-5 text-red-400" />
              ) : (
                <IconVolume2 className="w-5 h-5 text-emerald-400" />
              )}
            </button>

            {/* Close */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur-md border border-white/20 hover:bg-black/70 transition"
              aria-label="Закрыть"
            >
              <IconX className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Right Sidebar Actions */}
        <div className="relative z-20 self-end mr-3 mb-16 flex flex-col items-center gap-5">
          {/* Agent Avatar */}
          <div
            onClick={(e) => {
              e.stopPropagation();
              onClose();
              onOpenDetails(property);
            }}
            className="group relative flex flex-col items-center cursor-pointer"
            title="Открыть объявление"
          >
            <div className="h-12 w-12 rounded-full border-2 border-white overflow-hidden shadow-lg group-hover:scale-105 transition">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={property.agent.avatar}
                alt={property.agent.name}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-[#19a99a] text-[10px] text-white">
              ✓
            </div>
          </div>

          {/* Like */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(property.id);
            }}
            className="flex flex-col items-center gap-1 group"
            aria-label="В избранное"
          >
            <div
              className={`flex h-12 w-12 items-center justify-center rounded-full backdrop-blur-md transition group-hover:scale-110 shadow-lg ${
                isFav
                  ? "bg-red-500 text-white"
                  : "bg-black/40 text-white border border-white/20"
              }`}
            >
              <IconHeart
                filled={isFav}
                className={`w-6 h-6 ${isFav ? "text-white" : "text-white"}`}
              />
            </div>
            <span className="text-xs font-semibold text-white drop-shadow">
              {property.likesCount + (isFav ? 1 : 0)}
            </span>
          </button>

          {/* WhatsApp */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleWhatsApp();
            }}
            className="flex flex-col items-center gap-1 group"
            aria-label="Написать в WhatsApp"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg backdrop-blur-md transition group-hover:scale-110">
              <IconWhatsApp className="w-6 h-6" />
            </div>
            <span className="text-xs font-semibold text-white drop-shadow">
              WhatsApp
            </span>
          </button>

          {/* Call */}
          <a
            href={`tel:${property.agent.phone}`}
            onClick={(e) => e.stopPropagation()}
            className="flex flex-col items-center gap-1 group"
            aria-label="Позвонить"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#102d42] text-white border border-white/20 shadow-lg backdrop-blur-md transition group-hover:scale-110">
              <IconPhone className="w-6 h-6" />
            </div>
            <span className="text-xs font-semibold text-white drop-shadow">
              Звонок
            </span>
          </a>

          {/* Share */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleShare();
            }}
            className="flex flex-col items-center gap-1 group"
            aria-label="Поделиться"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-black/40 text-white border border-white/20 shadow-lg backdrop-blur-md transition group-hover:scale-110">
              <IconShare className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-white drop-shadow">
              Поделиться
            </span>
          </button>
        </div>

        {/* Bottom Info Bar & Switch to Full Details */}
        <div className="relative z-20 px-4 pb-4">
          <div className="mb-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tracking-tight drop-shadow-md">
              {formatPrice(property.price)} {property.currency}
            </span>
            <span className="text-xs text-white/80 font-medium bg-black/40 px-2 py-0.5 rounded backdrop-blur">
              {property.dealType}
            </span>
          </div>

          <h2 className="text-sm font-semibold text-white line-clamp-2 drop-shadow leading-snug">
            {property.title}
          </h2>

          <div className="mt-1 flex items-center gap-1 text-xs text-white/90 drop-shadow">
            <IconMapPin className="w-3.5 h-3.5 text-[#52c9b8] shrink-0" />
            <span className="truncate">{property.location.district}</span>
            {property.location.metro && (
              <span className="text-[#8be0d4]">• {property.location.metro}</span>
            )}
          </div>

          <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs font-medium text-white/90">
            <span className="rounded-lg bg-white/20 backdrop-blur-md px-2.5 py-1">
              {property.rooms} комн.
            </span>
            <span className="rounded-lg bg-white/20 backdrop-blur-md px-2.5 py-1">
              {property.area} м²
            </span>
            <span className="rounded-lg bg-white/20 backdrop-blur-md px-2.5 py-1">
              {property.floor}
            </span>
            {property.hasKupcha && (
              <span className="rounded-lg bg-emerald-500/80 backdrop-blur-md px-2 py-1 text-white text-[11px] font-bold">
                ✓ Купчая
              </span>
            )}
          </div>

          {/* Button: Open Full Detailed Announcement */}
          <button
            onClick={() => {
              onClose();
              onOpenDetails(property);
            }}
            className="mt-3.5 flex w-full items-center justify-between rounded-xl bg-white/95 px-4 py-3 text-sm font-bold text-[#102d42] backdrop-blur-md shadow-xl transition hover:bg-white active:scale-[0.98]"
          >
            <span>Открыть полное объявление (все фото и параметры)</span>
            <span className="text-[#19a99a] text-lg font-black">→</span>
          </button>

          {/* Progress bar */}
          <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-white/20">
            <div
              className="h-full bg-[#19a99a] transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
