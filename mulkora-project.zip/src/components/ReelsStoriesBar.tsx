"use client";

import React from "react";
import { Property } from "@/types/property";
import { IconPlay, IconSparkles } from "./Icons";

interface ReelsStoriesBarProps {
  properties: Property[];
  onSelectProperty: (property: Property) => void;
}

export default function ReelsStoriesBar({
  properties,
  onSelectProperty,
}: ReelsStoriesBarProps) {
  const videoProperties = properties.filter((p) => p.videoUrl);

  return (
    <div className="mx-auto max-w-7xl px-5 py-6">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-tr from-[#19a99a] to-[#52c9b8] text-white shadow-sm">
            <IconSparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#102d42]">
              Видео-туры Reels
            </h3>
            <p className="text-xs text-gray-500">
              Смотрите вертикальные видео-обзоры квартир и вилл
            </p>
          </div>
        </div>

        {videoProperties.length > 0 && (
          <button
            onClick={() => onSelectProperty(videoProperties[0])}
            className="hidden sm:flex items-center gap-1.5 rounded-full bg-[#102d42] px-3.5 py-1.5 text-xs font-semibold text-white transition hover:bg-[#19a99a]"
          >
            <IconPlay className="w-3 h-3 ml-0.5" />
            Смотреть все Reels
          </button>
        )}
      </div>

      <div className="flex gap-4 overflow-x-auto pb-3 pt-1 scrollbar-none">
        {videoProperties.map((p) => (
          <button
            key={p.id}
            onClick={() => onSelectProperty(p)}
            className="group flex flex-col items-center flex-shrink-0 text-center transition transform hover:-translate-y-1"
          >
            {/* Gradient Ring Story Circle */}
            <div className="relative p-[3px] rounded-full bg-gradient-to-tr from-[#102d42] via-[#19a99a] to-[#8be0d4] group-hover:scale-105 transition duration-300 shadow-md">
              <div className="h-20 w-20 sm:h-24 sm:w-24 rounded-full overflow-hidden border-2 border-white bg-black relative">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={p.videoPoster}
                  alt={p.title}
                  className="h-full w-full object-cover group-hover:scale-110 transition duration-500"
                />
                <div className="absolute inset-0 bg-black/25 flex items-center justify-center">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur-sm group-hover:bg-[#19a99a] transition">
                    <IconPlay className="w-3.5 h-3.5 ml-0.5 text-white" />
                  </div>
                </div>
              </div>
            </div>

            <span className="mt-2 text-xs font-bold text-[#102d42] truncate max-w-[90px]">
              {p.location.district.replace(" район", "")}
            </span>
            <span className="text-[11px] font-semibold text-[#19a99a]">
              {new Intl.NumberFormat("ru-RU").format(p.price)} ₼
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
