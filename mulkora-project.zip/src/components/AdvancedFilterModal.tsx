"use client";

import React from "react";
import { FilterState, DealType } from "@/types/property";
import { IconX } from "./Icons";

interface AdvancedFilterModalProps {
  isOpen: boolean;
  onClose: () => void;
  filters: FilterState;
  onChangeFilters: (newFilters: FilterState) => void;
  onResetFilters: () => void;
  resultsCount: number;
}

const BAKU_DISTRICTS = [
  "Все районы",
  "Ясамальский район",
  "Насиминский район",
  "Сабаильский район",
  "Хатаинский район",
  "Наримановский район",
  "Хазарский район",
  "Бинагадинский район",
  "Сабунчинский район",
];

const METRO_STATIONS = [
  "Все станции",
  "м. Низами",
  "м. Эльмляр Академиясы",
  "м. 28 Мая",
  "м. Сахил",
  "м. Ичери Шехер",
  "м. Нариман Нариманов",
  "м. Гянджлик",
  "м. Шах Исмаил Хатаи",
  "м. Кёроглу",
];

export default function AdvancedFilterModal({
  isOpen,
  onClose,
  filters,
  onChangeFilters,
  onResetFilters,
  resultsCount,
}: AdvancedFilterModalProps) {
  if (!isOpen) return null;

  const toggleRoom = (r: number) => {
    const current = [...filters.rooms];
    if (current.includes(r)) {
      onChangeFilters({
        ...filters,
        rooms: current.filter((x) => x !== r),
      });
    } else {
      onChangeFilters({
        ...filters,
        rooms: [...current, r].sort(),
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-5 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative my-auto w-full max-w-2xl overflow-hidden rounded-3xl bg-white shadow-2xl border border-gray-100 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-gray-100 bg-white px-6 py-4">
          <div>
            <h2 className="text-xl font-black text-[#102d42]">
              Расширенные фильтры поиска
            </h2>
            <p className="text-xs text-gray-500">
              Настройте параметры недвижимости под ваши пожелания
            </p>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 transition"
          >
            <IconX className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto px-6 py-5 space-y-6 text-sm text-gray-700">
          {/* Deal type: Buy / Rent */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-gray-400">
              Тип сделки
            </label>
            <div className="mt-2 flex gap-2">
              {(["Продажа", "Аренда"] as DealType[]).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => onChangeFilters({ ...filters, dealType: type })}
                  className={`flex-1 rounded-xl py-2.5 font-bold transition text-xs sm:text-sm ${
                    filters.dealType === type
                      ? "bg-[#102d42] text-white shadow-sm"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-gray-400">
              Категория недвижимости
            </label>
            <div className="mt-2 grid grid-cols-2 sm:grid-cols-4 gap-2">
              {["Все", "Квартиры", "Виллы и Дома", "Коммерция"].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => onChangeFilters({ ...filters, category: cat })}
                  className={`rounded-xl py-2 px-3 text-xs font-semibold border transition ${
                    filters.category === cat
                      ? "border-[#19a99a] bg-[#19a99a]/10 text-[#102d42] font-bold"
                      : "border-gray-200 text-gray-600 hover:border-gray-300"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Rooms */}
          <div>
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-400">
                Количество комнат
              </label>
              {filters.rooms.length > 0 && (
                <button
                  onClick={() => onChangeFilters({ ...filters, rooms: [] })}
                  className="text-xs font-semibold text-[#19a99a] hover:underline"
                >
                  Сбросить
                </button>
              )}
            </div>
            <div className="mt-2 flex gap-2">
              {[1, 2, 3, 4, 5].map((r) => {
                const isSelected = filters.rooms.includes(r);
                return (
                  <button
                    key={r}
                    type="button"
                    onClick={() => toggleRoom(r)}
                    className={`flex-1 rounded-xl py-2.5 font-bold text-xs sm:text-sm border transition ${
                      isSelected
                        ? "border-[#102d42] bg-[#102d42] text-white shadow-sm"
                        : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
                    }`}
                  >
                    {r === 5 ? "5+" : r}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-gray-400">
              Цена ({filters.dealType === "Продажа" ? "AZN ₼" : "AZN ₼/мес"})
            </label>
            <div className="mt-2 grid grid-cols-2 gap-3">
              <div>
                <input
                  type="number"
                  placeholder="От 0 ₼"
                  value={filters.minPrice}
                  onChange={(e) =>
                    onChangeFilters({ ...filters, minPrice: e.target.value })
                  }
                  className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs sm:text-sm outline-none focus:border-[#19a99a]"
                />
              </div>
              <div>
                <input
                  type="number"
                  placeholder="До 1 000 000 ₼"
                  value={filters.maxPrice}
                  onChange={(e) =>
                    onChangeFilters({ ...filters, maxPrice: e.target.value })
                  }
                  className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs sm:text-sm outline-none focus:border-[#19a99a]"
                />
              </div>
            </div>
          </div>

          {/* Area Range */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-gray-400">
              Площадь (м²)
            </label>
            <div className="mt-2 grid grid-cols-2 gap-3">
              <div>
                <input
                  type="number"
                  placeholder="От 30 м²"
                  value={filters.minArea}
                  onChange={(e) =>
                    onChangeFilters({ ...filters, minArea: e.target.value })
                  }
                  className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs sm:text-sm outline-none focus:border-[#19a99a]"
                />
              </div>
              <div>
                <input
                  type="number"
                  placeholder="До 500 м²"
                  value={filters.maxArea}
                  onChange={(e) =>
                    onChangeFilters({ ...filters, maxArea: e.target.value })
                  }
                  className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs sm:text-sm outline-none focus:border-[#19a99a]"
                />
              </div>
            </div>
          </div>

          {/* District & Metro */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-gray-400">
                Район Баку
              </label>
              <select
                value={filters.district}
                onChange={(e) =>
                  onChangeFilters({ ...filters, district: e.target.value })
                }
                className="mt-2 w-full rounded-xl border border-gray-200 bg-white p-2.5 text-xs sm:text-sm outline-none focus:border-[#19a99a]"
              >
                {BAKU_DISTRICTS.map((d) => (
                  <option key={d}>{d}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-gray-400">
                Станция метро
              </label>
              <select
                value={filters.metro}
                onChange={(e) =>
                  onChangeFilters({ ...filters, metro: e.target.value })
                }
                className="mt-2 w-full rounded-xl border border-gray-200 bg-white p-2.5 text-xs sm:text-sm outline-none focus:border-[#19a99a]"
              >
                {METRO_STATIONS.map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Building Type */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-gray-400">
              Тип здания
            </label>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {["Все", "Новостройка", "Вторичка"].map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => onChangeFilters({ ...filters, buildingType: b })}
                  className={`rounded-xl py-2 px-3 text-xs font-semibold border transition ${
                    filters.buildingType === b
                      ? "border-[#102d42] bg-[#102d42] text-white font-bold"
                      : "border-gray-200 text-gray-600 hover:border-gray-300"
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {/* Checkboxes: Kupcha, Gas, Mortgage, Video */}
          <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100 space-y-3">
            <label className="flex items-center gap-2.5 cursor-pointer text-xs sm:text-sm font-semibold">
              <input
                type="checkbox"
                checked={filters.hasKupcha}
                onChange={(e) =>
                  onChangeFilters({ ...filters, hasKupcha: e.target.checked })
                }
                className="h-4 w-4 rounded accent-[#19a99a]"
              />
              <span>Только с Купчей (Çıxarış var)</span>
            </label>

            <label className="flex items-center gap-2.5 cursor-pointer text-xs sm:text-sm font-semibold">
              <input
                type="checkbox"
                checked={filters.hasGas}
                onChange={(e) =>
                  onChangeFilters({ ...filters, hasGas: e.target.checked })
                }
                className="h-4 w-4 rounded accent-[#19a99a]"
              />
              <span>Газ подключен</span>
            </label>

            <label className="flex items-center gap-2.5 cursor-pointer text-xs sm:text-sm font-semibold">
              <input
                type="checkbox"
                checked={filters.isMortgage}
                onChange={(e) =>
                  onChangeFilters({ ...filters, isMortgage: e.target.checked })
                }
                className="h-4 w-4 rounded accent-[#19a99a]"
              />
              <span>Подходит под ипотеку</span>
            </label>

            <label className="flex items-center gap-2.5 cursor-pointer text-xs sm:text-sm font-semibold text-[#19a99a]">
              <input
                type="checkbox"
                checked={filters.onlyWithVideo}
                onChange={(e) =>
                  onChangeFilters({
                    ...filters,
                    onlyWithVideo: e.target.checked,
                  })
                }
                className="h-4 w-4 rounded accent-[#19a99a]"
              />
              <span>Только с видео-туром Reels</span>
            </label>
          </div>

          {/* Sort By */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-gray-400">
              Сортировка результатов
            </label>
            <select
              value={filters.sortBy}
              onChange={(e) =>
                onChangeFilters({
                  ...filters,
                  sortBy: e.target.value as FilterState["sortBy"],
                })
              }
              className="mt-2 w-full rounded-xl border border-gray-200 bg-white p-2.5 text-xs sm:text-sm outline-none focus:border-[#19a99a]"
            >
              <option value="default">По умолчанию</option>
              <option value="price_asc">Сначала дешевле (по возрастанию цены)</option>
              <option value="price_desc">Сначала дороже (по убыванию цены)</option>
              <option value="area_desc">По площади (сначала просторные)</option>
              <option value="newest">Сначала новые предложения</option>
            </select>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="sticky bottom-0 z-10 flex items-center justify-between border-t border-gray-100 bg-white px-6 py-4">
          <button
            type="button"
            onClick={onResetFilters}
            className="text-xs font-bold text-gray-500 hover:text-red-500 transition"
          >
            Сбросить все
          </button>

          <button
            type="button"
            onClick={onClose}
            className="rounded-2xl bg-[#19a99a] px-6 py-3 text-xs sm:text-sm font-bold text-white shadow-lg transition hover:bg-[#138b80]"
          >
            Показать {resultsCount} {resultsCount === 1 ? "объект" : "объектов"}
          </button>
        </div>
      </div>
    </div>
  );
}
