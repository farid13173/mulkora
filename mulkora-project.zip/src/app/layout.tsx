import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MULKORA — Недвижимость в Азербайджане | Daşınmaz əmlak",
  description:
    "Покупка, продажа и аренда квартир, домов и коммерческой недвижимости в Баку. Смотрите видео-туры в формате Reels и находите жилье мечты.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="az" className="h-full antialiased">
      <body className="min-h-full flex flex-col font-sans bg-[#f7f8fa] text-[#172333]">
        {children}
      </body>
    </html>
  );
}
