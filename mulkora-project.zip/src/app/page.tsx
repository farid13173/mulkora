"use client";

import React, { useState, useMemo } from "react";
import { initialProperties } from "@/data/properties";
import { Property, FilterState, DealType } from "@/types/property";
import PropertyDetailModal from "@/components/PropertyDetailModal";
import PropertyReelsModal from "@/components/PropertyReelsModal";
import AdvancedFilterModal from "@/components/AdvancedFilterModal";
import ReelsStoriesBar from "@/components/ReelsStoriesBar";
import PropertyCard from "@/components/PropertyCard";
import MobileAppModal from "@/components/MobileAppModal";
import AddPropertyModal from "@/components/AddPropertyModal";
import {
  IconHeart,
  IconSmartphone,
  IconPlay,
  IconFilter,
  IconCheck,
  IconX,
} from "@/components/Icons";

const defaultFilters: FilterState = {
  dealType: "Продажа",
  category: "Все",
  searchQuery: "",
  district: "Все районы",
  metro: "Все станции",
  rooms: [],
  minPrice: "",
  maxPrice: "",
  minArea: "",
  maxArea: "",
  buildingType: "Все",
  hasKupcha: false,
  hasGas: false,
  isMortgage: false,
  onlyWithVideo: false,
  sortBy: "default",
};

export default function Home() {
  const [properties, setProperties] = useState<Property[]>(initialProperties);
  const [language, setLanguage] = useState("AZ");
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const [favorites, setFavorites] = useState<number[]>([]);
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);

  // Modals state
  const [selectedDetailProperty, setSelectedDetailProperty] =
    useState<Property | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const [selectedReelsProperty, setSelectedReelsProperty] =
    useState<Property | null>(null);
  const [isReelsOpen, setIsReelsOpen] = useState(false);

  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [isAppModalOpen, setIsAppModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Toggle favorite
  const handleToggleFavorite = (id: number) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Open Property Details (full view)
  const handleOpenDetails = (prop: Property) => {
    setSelectedDetailProperty(prop);
    setIsDetailOpen(true);
  };

  // Open Reels (separate video player)
  const handleOpenReels = (prop: Property) => {
    setSelectedReelsProperty(prop);
    setIsReelsOpen(true);
  };

  // Add new property
  const handleAddProperty = (newProp: Property) => {
    setProperties((prev) => [newProp, ...prev]);
  };

  // Reset filters
  const handleResetFilters = () => {
    setFilters(defaultFilters);
    setShowOnlyFavorites(false);
  };

  // Active filter count for badge
  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (filters.category !== "Все") count++;
    if (filters.district !== "Все районы") count++;
    if (filters.metro !== "Все станции") count++;
    if (filters.rooms.length > 0) count++;
    if (filters.minPrice || filters.maxPrice) count++;
    if (filters.minArea || filters.maxArea) count++;
    if (filters.buildingType !== "Все") count++;
    if (filters.hasKupcha) count++;
    if (filters.hasGas) count++;
    if (filters.isMortgage) count++;
    if (filters.onlyWithVideo) count++;
    if (filters.sortBy !== "default") count++;
    return count;
  }, [filters]);

  // Filter and sort properties
  const filteredProperties = useMemo(() => {
    return properties
      .filter((p) => {
        if (showOnlyFavorites && !favorites.includes(p.id)) return false;

        // Deal type
        if (p.dealType !== filters.dealType) return false;

        // Category
        if (filters.category === "Квартиры" && p.type !== "Квартира") return false;
        if (
          filters.category === "Виллы и Дома" &&
          p.type !== "Вилла" &&
          p.type !== "Дом"
        )
          return false;
        if (filters.category === "Коммерция" && p.type !== "Коммерция") return false;

        // Search text
        if (filters.searchQuery.trim()) {
          const query = filters.searchQuery.toLowerCase();
          const haystack = (
            p.title +
            " " +
            p.location.district +
            " " +
            (p.location.metro || "") +
            " " +
            p.location.address +
            " " +
            p.description
          ).toLowerCase();
          if (!haystack.includes(query)) return false;
        }

        // District
        if (
          filters.district !== "Все районы" &&
          p.location.district !== filters.district
        ) {
          return false;
        }

        // Metro
        if (
          filters.metro !== "Все станции" &&
          p.location.metro !== filters.metro
        ) {
          return false;
        }

        // Rooms
        if (filters.rooms.length > 0) {
          const matchRoom = filters.rooms.some((r) =>
            r === 5 ? p.rooms >= 5 : p.rooms === r
          );
          if (!matchRoom) return false;
        }

        // Price
        if (filters.minPrice && p.price < Number(filters.minPrice)) return false;
        if (filters.maxPrice && p.price > Number(filters.maxPrice)) return false;

        // Area
        if (filters.minArea && p.area < Number(filters.minArea)) return false;
        if (filters.maxArea && p.area > Number(filters.maxArea)) return false;

        // Building Type
        if (
          filters.buildingType !== "Все" &&
          p.buildingType !== filters.buildingType
        ) {
          return false;
        }

        // Flags
        if (filters.hasKupcha && !p.hasKupcha) return false;
        if (filters.hasGas && !p.hasGas) return false;
        if (filters.isMortgage && !p.isMortgage) return false;
        if (filters.onlyWithVideo && !p.videoUrl) return false;

        return true;
      })
      .sort((a, b) => {
        if (filters.sortBy === "price_asc") return a.price - b.price;
        if (filters.sortBy === "price_desc") return b.price - a.price;
        if (filters.sortBy === "area_desc") return b.area - a.area;
        if (filters.sortBy === "newest") return b.id - a.id;
        return 0;
      });
  }, [properties, filters, favorites, showOnlyFavorites]);

  return (
    <main className="min-h-screen bg-[#f7f8fa] text-[#172333]">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-gray-100 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3.5">
          {/* Logo */}
          <a
            href="#"
            className="flex items-center gap-1 text-2xl font-black tracking-tight text-[#102d42]"
          >
            <span>MULK</span>
            <span className="text-[#19a99a]">ORA</span>
            <span className="ml-1 rounded bg-[#102d42] px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
              Baku
            </span>
          </a>

          {/* Navigation links */}
          <nav className="hidden items-center gap-6 text-sm font-semibold md:flex text-gray-700">
            <a href="#catalog" className="hover:text-[#19a99a] transition">
              Недвижимость
            </a>
            <button
              onClick={() => handleOpenReels(properties[0])}
              className="flex items-center gap-1.5 text-[#19a99a] hover:opacity-80 transition"
            >
              <IconPlay className="w-3.5 h-3.5 fill-[#19a99a]" />
              Видео-туры Reels
            </button>
            <button
              onClick={() => setIsAppModalOpen(true)}
              className="flex items-center gap-1 hover:text-[#19a99a] transition"
            >
              <IconSmartphone className="w-4 h-4 text-[#19a99a]" />
              Приложение для телефона
            </button>
          </nav>

          {/* Header Action Buttons */}
          <div className="flex items-center gap-2.5">
            {/* Mobile App pill */}
            <button
              onClick={() => setIsAppModalOpen(true)}
              className="flex items-center gap-1 rounded-xl border border-gray-200 bg-gray-50 px-2.5 py-2 text-xs font-bold text-gray-700 hover:border-[#19a99a] sm:px-3 sm:text-sm"
              title="Приложение для Android и iPhone"
            >
              <IconSmartphone className="w-4 h-4 text-[#19a99a]" />
              <span className="hidden sm:inline">iOS / Android</span>
              <span className="sm:hidden">App</span>
            </button>

            {/* Favorites button */}
            <button
              onClick={() => setShowOnlyFavorites(!showOnlyFavorites)}
              className={`flex items-center gap-1 rounded-xl border px-3 py-2 text-xs font-bold transition ${
                showOnlyFavorites
                  ? "border-red-400 bg-red-50 text-red-600"
                  : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
              }`}
            >
              <IconHeart
                filled={favorites.length > 0}
                className={`w-4 h-4 ${
                  favorites.length > 0 ? "text-red-500 fill-red-500" : "text-gray-500"
                }`}
              />
              <span className="hidden sm:inline">Избранное</span>
              {favorites.length > 0 && (
                <span className="rounded-full bg-red-500 px-1.5 py-0.2 text-[10px] text-white">
                  {favorites.length}
                </span>
              )}
            </button>

            {/* Language switcher */}
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="rounded-xl border border-gray-200 bg-white px-2 py-2 text-xs font-bold outline-none cursor-pointer"
              aria-label="Выбор языка"
            >
              <option>AZ</option>
              <option>RU</option>
              <option>EN</option>
            </select>

            {/* Add Property Button */}
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="rounded-xl bg-[#102d42] px-3.5 py-2 text-xs font-bold text-white shadow transition hover:bg-[#19a99a] sm:px-4 sm:text-sm"
            >
              + Объявление
            </button>
          </div>
        </div>
      </header>

      {/* Hero Banner with Search Box */}
      <section className="relative overflow-hidden bg-[#102d42]">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage:
              "url(https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1800)",
          }}
        />
        <div className="relative mx-auto max-w-7xl px-5 py-14 md:py-20">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-bold tracking-widest text-[#8be0d4] backdrop-blur-md">
              <span className="h-2 w-2 rounded-full bg-[#19a99a] animate-ping" />
              ЖИВЫЕ ВИДЕО-ТУРЫ REELS И ПОЛНЫЕ ОБЪЯВЛЕНИЯ
            </div>

            <h1 className="mt-6 text-3xl font-extrabold leading-tight text-white sm:text-5xl md:text-6xl">
              Находите лучшее жилье <br />
              <span className="text-[#52c9b8]">в Баку</span> с видео и всеми деталями
            </h1>

            <p className="mt-4 max-w-xl text-sm leading-relaxed text-white/75 sm:text-base">
              Нажмите на любое объявление, чтобы изучить подробные характеристики и фотографии, или запустите видео-тур Reels отдельно.
            </p>

            {/* Search Card */}
            <div className="mt-8 rounded-3xl bg-white p-4 shadow-2xl">
              {/* Buy / Rent & Categories */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-3">
                <div className="flex gap-1.5">
                  {(["Продажа", "Аренда"] as DealType[]).map((type) => (
                    <button
                      key={type}
                      onClick={() => setFilters({ ...filters, dealType: type })}
                      className={`rounded-xl px-4 py-2 text-xs font-bold transition sm:text-sm ${
                        filters.dealType === type
                          ? "bg-[#102d42] text-white shadow-sm"
                          : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>

                <div className="flex flex-wrap gap-1">
                  {["Все", "Квартиры", "Виллы и Дома", "Коммерция"].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setFilters({ ...filters, category: cat })}
                      className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                        filters.category === cat
                          ? "bg-[#19a99a]/15 text-[#102d42] font-bold border border-[#19a99a]"
                          : "text-gray-600 hover:bg-gray-100"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Main Search Input & Filter Opener */}
              <div className="mt-3 flex flex-col sm:flex-row gap-2.5">
                <div className="relative flex-1">
                  <input
                    value={filters.searchQuery}
                    onChange={(e) =>
                      setFilters({ ...filters, searchQuery: e.target.value })
                    }
                    placeholder="Район (Ясамал, Белый город...), метро, улица или ЖК..."
                    className="w-full rounded-2xl bg-gray-50 px-4 py-3.5 text-sm text-[#102d42] outline-none focus:ring-2 focus:ring-[#19a99a]"
                  />
                  {filters.searchQuery && (
                    <button
                      type="button"
                      onClick={() =>
                        setFilters({ ...filters, searchQuery: "" })
                      }
                      className="absolute right-3 top-3.5 text-xs text-gray-400 hover:text-gray-600"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Extensive Filter Button */}
                <button
                  type="button"
                  onClick={() => setIsFilterModalOpen(true)}
                  className="flex items-center justify-center gap-2 rounded-2xl border border-gray-200 bg-gray-50 px-5 py-3.5 text-xs sm:text-sm font-bold text-[#102d42] hover:border-[#19a99a] transition"
                >
                  <IconFilter className="w-4 h-4 text-[#19a99a]" />
                  <span>Фильтры</span>
                  {activeFiltersCount > 0 && (
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#19a99a] text-[10px] font-bold text-white">
                      {activeFiltersCount}
                    </span>
                  )}
                </button>

                {/* Find CTA */}
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("catalog")?.scrollIntoView({
                      behavior: "smooth",
                    });
                  }}
                  className="rounded-2xl bg-[#19a99a] px-8 py-3.5 text-xs sm:text-sm font-bold text-white shadow transition hover:bg-[#138b80]"
                >
                  Найти
                </button>
              </div>
            </div>

            {/* Quick Hero Links */}
            <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-white/70">
              <button
                onClick={() => setIsAppModalOpen(true)}
                className="flex items-center gap-1.5 font-semibold text-[#8be0d4] hover:underline"
              >
                <IconSmartphone className="w-4 h-4" />
                Приложение на телефон (Android и iPhone)
              </button>
              <span>•</span>
              <button
                onClick={() => handleOpenReels(properties[0])}
                className="flex items-center gap-1 text-white hover:text-[#8be0d4]"
              >
                <IconPlay className="w-3.5 h-3.5 fill-white" />
                Смотреть только видео-туры
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stories / Reels Bar */}
      <ReelsStoriesBar
        properties={properties}
        onSelectProperty={handleOpenReels}
      />

      {/* Catalog & Filter Bar */}
      <section id="catalog" className="mx-auto max-w-7xl px-5 pt-4 pb-20">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-gray-200 pb-5">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#19a99a]">
              КАТАЛОГ НЕДВИЖИМОСТИ БАКУ
            </span>
            <h2 className="mt-1 text-2xl font-black text-[#102d42] sm:text-3xl">
              {showOnlyFavorites
                ? `Сохранённые объекты (${favorites.length})`
                : `${filters.dealType}: ${filters.category}`}
            </h2>
          </div>

          {/* Quick Toggles */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Kupcha toggle */}
            <button
              onClick={() =>
                setFilters({ ...filters, hasKupcha: !filters.hasKupcha })
              }
              className={`flex items-center gap-1 rounded-xl px-3.5 py-2 text-xs font-bold transition ${
                filters.hasKupcha
                  ? "bg-emerald-600 text-white shadow-sm"
                  : "border border-gray-200 bg-white text-gray-600 hover:border-emerald-500"
              }`}
            >
              <IconCheck className="w-3.5 h-3.5" />
              Купчая
            </button>

            {/* Mortgage toggle */}
            <button
              onClick={() =>
                setFilters({ ...filters, isMortgage: !filters.isMortgage })
              }
              className={`flex items-center gap-1 rounded-xl px-3.5 py-2 text-xs font-bold transition ${
                filters.isMortgage
                  ? "bg-blue-600 text-white shadow-sm"
                  : "border border-gray-200 bg-white text-gray-600 hover:border-blue-500"
              }`}
            >
              Ипотека
            </button>

            {/* Video Reels Only toggle */}
            <button
              onClick={() =>
                setFilters({ ...filters, onlyWithVideo: !filters.onlyWithVideo })
              }
              className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition ${
                filters.onlyWithVideo
                  ? "bg-[#19a99a] text-white shadow-sm"
                  : "border border-gray-200 bg-white text-gray-600 hover:border-[#19a99a]"
              }`}
            >
              <IconPlay className="w-3 h-3 fill-current" />
              Только с Reels
            </button>

            {/* Open All Filters Modal Button */}
            <button
              onClick={() => setIsFilterModalOpen(true)}
              className="flex items-center gap-1.5 rounded-xl bg-[#102d42] px-4 py-2 text-xs font-bold text-white transition hover:bg-[#19a99a]"
            >
              <IconFilter className="w-3.5 h-3.5" />
              <span>Все фильтры</span>
              {activeFiltersCount > 0 && (
                <span className="rounded-full bg-[#19a99a] px-1.5 py-0.2 text-[10px]">
                  {activeFiltersCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Active Filters Badges Row */}
        {activeFiltersCount > 0 && (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-gray-400">Применено:</span>

            {filters.district !== "Все районы" && (
              <span className="flex items-center gap-1 rounded-lg bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">
                {filters.district}
                <button
                  onClick={() =>
                    setFilters({ ...filters, district: "Все районы" })
                  }
                  className="hover:text-red-500"
                >
                  <IconX className="w-3 h-3" />
                </button>
              </span>
            )}

            {filters.metro !== "Все станции" && (
              <span className="flex items-center gap-1 rounded-lg bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">
                {filters.metro}
                <button
                  onClick={() =>
                    setFilters({ ...filters, metro: "Все станции" })
                  }
                  className="hover:text-red-500"
                >
                  <IconX className="w-3 h-3" />
                </button>
              </span>
            )}

            {filters.rooms.length > 0 && (
              <span className="flex items-center gap-1 rounded-lg bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">
                Комнат: {filters.rooms.join(", ")}
                <button
                  onClick={() => setFilters({ ...filters, rooms: [] })}
                  className="hover:text-red-500"
                >
                  <IconX className="w-3 h-3" />
                </button>
              </span>
            )}

            {(filters.minPrice || filters.maxPrice) && (
              <span className="flex items-center gap-1 rounded-lg bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">
                Цена: {filters.minPrice || "0"} - {filters.maxPrice || "∞"} ₼
                <button
                  onClick={() =>
                    setFilters({ ...filters, minPrice: "", maxPrice: "" })
                  }
                  className="hover:text-red-500"
                >
                  <IconX className="w-3 h-3" />
                </button>
              </span>
            )}

            <button
              onClick={handleResetFilters}
              className="text-xs font-bold text-red-500 hover:underline ml-1"
            >
              Сбросить все
            </button>
          </div>
        )}

        {/* Results Counter & Sort bar */}
        <div className="my-5 flex flex-wrap items-center justify-between gap-3 text-xs text-gray-500">
          <div>
            Найдено объектов: <strong>{filteredProperties.length}</strong>
          </div>

          <div className="flex items-center gap-2">
            <span>Сортировка:</span>
            <select
              value={filters.sortBy}
              onChange={(e) =>
                setFilters({
                  ...filters,
                  sortBy: e.target.value as FilterState["sortBy"],
                })
              }
              className="rounded-lg border border-gray-200 bg-white px-2 py-1 text-xs font-bold text-gray-700 outline-none"
            >
              <option value="default">По умолчанию</option>
              <option value="price_asc">Сначала дешевле</option>
              <option value="price_desc">Сначала дороже</option>
              <option value="area_desc">По площади</option>
              <option value="newest">Сначала новые</option>
            </select>
          </div>
        </div>

        {/* Property Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredProperties.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              isFavorite={favorites.includes(property.id)}
              onToggleFavorite={handleToggleFavorite}
              onOpenDetails={handleOpenDetails}
              onOpenReels={handleOpenReels}
            />
          ))}
        </div>

        {/* Empty state */}
        {filteredProperties.length === 0 && (
          <div className="my-16 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gray-100 text-2xl text-gray-400">
              🔍
            </div>
            <h3 className="mt-4 text-base font-bold text-gray-800">
              По вашим фильтрам ничего не найдено
            </h3>
            <p className="mt-1 text-xs text-gray-500">
              Попробуйте смягчить параметры поиска или сбросить фильтры
            </p>
            <button
              onClick={handleResetFilters}
              className="mt-4 rounded-xl bg-[#102d42] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#19a99a]"
            >
              Сбросить все фильтры
            </button>
          </div>
        )}
      </section>

      {/* Mobile App Promo */}
      <section className="bg-gradient-to-r from-[#102d42] to-[#14425f] px-5 py-14 text-white">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-8 md:flex-row">
          <div className="max-w-xl text-center md:text-left">
            <span className="rounded-full bg-[#19a99a]/30 border border-[#19a99a] px-3.5 py-1 text-xs font-bold text-[#8be0d4]">
              ПРИЛОЖЕНИЕ ДЛЯ СМАРТФОНА
            </span>
            <h2 className="mt-4 text-3xl font-extrabold sm:text-4xl">
              Ищите жилье на iPhone и Android
            </h2>
            <p className="mt-3 text-sm text-white/75 leading-relaxed">
              Листайте видео-туры свайпами, получайте мгновенные уведомления о снижении цен и пишите риелторам в один клик.
            </p>
            <div className="mt-6 flex flex-wrap justify-center md:justify-start gap-3">
              <button
                onClick={() => setIsAppModalOpen(true)}
                className="flex items-center gap-2 rounded-xl bg-white px-5 py-3 text-xs font-bold text-[#102d42] shadow transition hover:bg-gray-100"
              >
                <IconSmartphone className="w-4 h-4 text-[#19a99a]" />
                Установить на iPhone / Android
              </button>
            </div>
          </div>

          <div className="flex items-center justify-center">
            <div
              onClick={() => handleOpenReels(properties[0])}
              className="group relative h-72 w-44 cursor-pointer rounded-[32px] border-4 border-white/20 bg-black p-2 shadow-2xl transition duration-500 hover:scale-105"
            >
              <div className="relative h-full w-full overflow-hidden rounded-[24px]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={properties[0].videoPoster}
                  alt="App preview"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-black/30 flex flex-col items-center justify-center text-center p-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#19a99a] text-white shadow-lg animate-pulse">
                    <IconPlay className="w-5 h-5 ml-0.5" />
                  </div>
                  <span className="mt-2 text-[10px] font-bold text-white">
                    Запустить Reels тур
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 px-5 py-10">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-6 text-xs text-gray-500">
          <div className="flex items-center gap-2">
            <span className="text-xl font-black text-[#102d42]">
              MULK<span className="text-[#19a99a]">ORA</span>
            </span>
            <span>— Daşınmaz əmlak platforması</span>
          </div>

          <div className="flex flex-wrap gap-4 font-semibold text-gray-600">
            <button
              onClick={() => handleOpenReels(properties[0])}
              className="hover:text-[#19a99a]"
            >
              Видео-туры Reels
            </button>
            <button
              onClick={() => setIsAppModalOpen(true)}
              className="hover:text-[#19a99a]"
            >
              Мобильное приложение
            </button>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="hover:text-[#19a99a]"
            >
              Подать объявление
            </button>
          </div>

          <span>© 2026 MULKORA. Баку, Азербайджан.</span>
        </div>
      </footer>

      {/* Detailed Property Modal (Full announcement with photos & specs) */}
      {selectedDetailProperty && (
        <PropertyDetailModal
          property={selectedDetailProperty}
          isOpen={isDetailOpen}
          onClose={() => setIsDetailOpen(false)}
          onOpenReels={handleOpenReels}
          isFavorite={favorites.includes(selectedDetailProperty.id)}
          onToggleFavorite={handleToggleFavorite}
        />
      )}

      {/* Reels Standalone Video Player Modal */}
      {selectedReelsProperty && (
        <PropertyReelsModal
          property={selectedReelsProperty}
          allProperties={properties}
          isOpen={isReelsOpen}
          onClose={() => setIsReelsOpen(false)}
          onSelectProperty={(prop) => setSelectedReelsProperty(prop)}
          onOpenDetails={handleOpenDetails}
          favorites={favorites}
          onToggleFavorite={handleToggleFavorite}
        />
      )}

      {/* Extensive Filter Modal */}
      <AdvancedFilterModal
        isOpen={isFilterModalOpen}
        onClose={() => setIsFilterModalOpen(false)}
        filters={filters}
        onChangeFilters={setFilters}
        onResetFilters={handleResetFilters}
        resultsCount={filteredProperties.length}
      />

      {/* Mobile App Modal */}
      <MobileAppModal
        isOpen={isAppModalOpen}
        onClose={() => setIsAppModalOpen(false)}
      />

      {/* Add Property Modal */}
      <AddPropertyModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={handleAddProperty}
      />
    </main>
  );
}
