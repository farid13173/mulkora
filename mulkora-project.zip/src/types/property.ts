export type PropertyType = "Квартира" | "Дом" | "Вилла" | "Коммерция" | "Участок";
export type DealType = "Продажа" | "Аренда";

export interface Agent {
  name: string;
  agency: string;
  phone: string;
  whatsapp: string; // номер без плюса: 994501234567
  avatar: string;
  rating: number;
  verified: boolean;
}

export interface PropertyLocation {
  city: string;
  district: string;
  metro?: string;
  address: string;
}

export interface Property {
  id: number;
  type: PropertyType;
  dealType: DealType;
  title: string;
  location: PropertyLocation;
  price: number;
  currency: string;
  rooms: number;
  area: number; // м²
  livingArea?: number;
  kitchenArea?: number;
  floor: string; // e.g. "8/16"
  floorNumber?: number;
  totalFloors?: number;
  buildingType: "Новостройка" | "Вторичка" | "Частный дом" | "Бизнес-центр";
  renovation: "Дизайнерский" | "Евроремонт" | "Хороший ремонт" | "Без ремонта (под маяк)";
  ceilingHeight?: string; // "3.2 м"
  heating?: string; // "Комби" | "Центральное"
  hasGas: boolean;
  hasKupcha: boolean; // Çıxarış
  isMortgage: boolean; // İpoteka
  description: string;
  features: string[];
  images: string[];
  videoUrl?: string; // вертикальное видео 9:16
  videoPoster: string;
  tag: string;
  agent: Agent;
  viewsCount: number;
  likesCount: number;
  createdAt: string;
}

export interface FilterState {
  dealType: DealType;
  category: string;
  searchQuery: string;
  district: string;
  metro: string;
  rooms: number[]; // e.g. [1, 2] or [] for any
  minPrice: string;
  maxPrice: string;
  minArea: string;
  maxArea: string;
  buildingType: string;
  hasKupcha: boolean;
  hasGas: boolean;
  isMortgage: boolean;
  onlyWithVideo: boolean;
  sortBy: "default" | "price_asc" | "price_desc" | "area_desc" | "newest";
}
